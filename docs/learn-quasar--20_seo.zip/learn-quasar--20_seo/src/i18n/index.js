import enUS from './en-US';
import koKR from './ko-KR';
export default {
  'en-US': enUS,
  'ko-KR': koKR,
};
