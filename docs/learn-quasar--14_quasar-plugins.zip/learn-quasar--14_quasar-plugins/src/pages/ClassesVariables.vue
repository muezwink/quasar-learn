<template>
  <q-page class="q-pa-xl">
    <section class="q-mb-xl">
      <div class="text-h4">Shadow</div>
      <q-separator class="q-my-md" />
      <div class="q-gutter-y-sm">
        <div class="shadow-1 q-pa-sm">shadow-1</div>
        <div class="shadow-7 q-pa-sm">shadow-7</div>
        <div class="shadow-24 q-pa-sm">shadow-24</div>
      </div>
    </section>
    <section class="q-mb-xl">
      <div class="text-h4">Visibility</div>
      <q-separator class="q-my-md" />
      <div class="ellipsis">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore hic
        consequuntur atque, odio iusto repellat id excepturi nihil, beatae
        minima sapiente ab explicabo, sequi enim ut nisi veritatis. Aliquid,
        dolor!
      </div>
      <hr />
      <div class="ellipsis-2-lines cursor-pointer">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore hic
        consequuntur atque, odio iusto repellat id excepturi nihil, beatae
        minima sapiente ab explicabo, sequi enim ut nisi veritatis. Aliquid,
        dolor!
      </div>
      <hr />
      <div class="ellipsis-3-lines">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore hic
        consequuntur atque, odio iusto repellat id excepturi nihil, beatae
        minima sapiente ab explicabo, sequi enim ut nisi veritatis. Aliquid,
        dolor!
      </div>
    </section>
  </q-page>
</template>

<script setup></script>

<style lang="scss" scoped></style>
