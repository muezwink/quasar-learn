export default {
  productName: '퀘이사 강의',
  hello: '안녕하세요~!',
};
