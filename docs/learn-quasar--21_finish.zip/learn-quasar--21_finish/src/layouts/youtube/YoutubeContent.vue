<template>
  <q-page-container>
    <router-view />
  </q-page-container>
</template>

<script setup></script>

<style lang="scss" scoped></style>
