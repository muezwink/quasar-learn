<template>
  <q-item clickable tag="a" :to="to" active-class="text-secondary">
    <q-item-section v-if="icon" avatar>
      <q-icon :name="icon" />
    </q-item-section>

    <q-item-section>
      <q-item-label>{{ localeTitle ? $t(localeTitle) : title }}</q-item-label>
      <q-item-label caption>{{ caption }}</q-item-label>
    </q-item-section>
  </q-item>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true,
  },

  localeTitle: {
    type: String,
    default: '',
  },

  caption: {
    type: String,
    default: '',
  },

  to: {
    type: String,
    default: '#',
  },

  icon: {
    type: String,
    default: '',
  },
});
</script>
