export default {
  productName: 'Quasar Lecture',
  hello: 'hello~!',
  'title.typography': 'Typography',
  'title.colors': 'Colors',
  'title.spacing': 'Spacing',
  'title.breakpoints': 'Breakpoints',
  'title.classes_variables': 'Classes & Variables',
  'title.flexgrid': 'Flex Grid 1',
  'title.form_handling': 'Form Handling',
  'title.quasar_utils': 'Quasar Utils',
  'title.quasar_language_packs': 'Quasar Language Packs',
};
