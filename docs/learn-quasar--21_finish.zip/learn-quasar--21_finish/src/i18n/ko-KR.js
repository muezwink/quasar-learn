export default {
  productName: '퀘이사 강의',
  hello: '안녕하세요~!',
  'title.typography': '타이포그래피',
  'title.colors': '색상',
  'title.spacing': '간격',
  'title.breakpoints': '중단점',
  'title.classes_variables': 'SASS 클래스 & 변수',
  'title.flexgrid': '플렉스 그리드',
  'title.form_handling': '폼 처리',
  'title.quasar_utils': '퀘이사 유틸',
  'title.quasar_language_packs': '퀘이사 언어 팩',
};
