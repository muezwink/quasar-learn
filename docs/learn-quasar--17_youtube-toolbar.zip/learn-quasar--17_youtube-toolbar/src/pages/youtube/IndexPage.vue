<template>
  <q-page class="flex flex-center"> Youtube Index Page </q-page>
</template>

<script setup></script>
