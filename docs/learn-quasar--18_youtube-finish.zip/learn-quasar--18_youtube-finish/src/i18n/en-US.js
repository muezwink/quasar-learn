export default {
  productName: 'Quasar Lecture',
  hello: 'hello~!',
};
