<template>
  <q-page class="flex flex-center">
    <div class="text-h2">Sub Page 2</div>
  </q-page>
</template>

<script setup></script>
